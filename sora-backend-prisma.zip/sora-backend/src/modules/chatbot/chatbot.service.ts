import { AppError } from "../../middlewares/error-handler";
import { env } from "../../config/env";

export class ChatbotService {
  async ask(message: string): Promise<string> {
    if (!env.openAiApiKey) {
      throw new AppError("Configure OPENAI_API_KEY no arquivo .env para usar o chatbot.", 503);
    }
    if (!message?.trim()) throw new AppError("A mensagem não pode ficar vazia.");

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${env.openAiApiKey}`
      },
      body: JSON.stringify({
        model: env.openAiModel,
        messages: [
          {
            role: "system",
            content: "Você é a SORA, uma assistente doméstica cordial, objetiva e segura. Ajude com organização, tarefas e dúvidas gerais. Não afirme que executou ações físicas na casa. Para assuntos médicos, financeiros ou de segurança, dê orientações gerais e recomende procurar profissionais ou serviços adequados."
          },
          { role: "user", content: message.trim() }
        ],
        temperature: 0.5
      })
    });

    const payload = await response.json() as {
      choices?: Array<{ message?: { content?: string } }>;
      error?: { message?: string };
    };

    if (!response.ok) {
      throw new AppError(payload.error?.message ?? "Falha ao consultar o serviço de IA.", 502);
    }
    const answer = payload.choices?.[0]?.message?.content;
    if (!answer) throw new AppError("O serviço de IA não retornou uma resposta.", 502);
    return answer;
  }
}
