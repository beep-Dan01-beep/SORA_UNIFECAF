/**
 * @swagger
 * tags:
 *   name: ChatBot
 *   description: Conversa com a assistente SORA
 * /api/chat:
 *   post:
 *     summary: Envia uma mensagem para a SORA
 *     tags: [ChatBot]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [message]
 *             properties:
 *               message: { type: string, example: "O que preciso fazer hoje?" }
 *     responses:
 *       200: { description: Resposta da assistente }
 *       503: { description: Chave da API não configurada }
 */
export {};
